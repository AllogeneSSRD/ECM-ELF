#include "ecm_worktodo.h"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#else
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

namespace {

void trim(std::string &s) {
    while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) {
        s.pop_back();
    }
    while (!s.empty() && std::isspace(static_cast<unsigned char>(s.front()))) {
        s.erase(s.begin());
    }
}

void strip_bom(std::string &s) {
    if (s.size() >= 3 && static_cast<unsigned char>(s[0]) == 0xEF &&
        static_cast<unsigned char>(s[1]) == 0xBB &&
        static_cast<unsigned char>(s[2]) == 0xBF) {
        s.erase(0, 3);
    }
}

bool is_int_like(const std::string &s) {
    std::string t = s;
    trim(t);
    if (t.empty()) {
        return false;
    }
    if (t[0] == '-' || t[0] == '+') {
        t.erase(t.begin());
    }
    if (t.empty()) {
        return false;
    }
    for (char c : t) {
        if (!std::isdigit(static_cast<unsigned char>(c))) {
            return false;
        }
    }
    return true;
}

bool starts_with(const std::string &s, const std::string &prefix) {
    return s.size() >= prefix.size() && s.compare(0, prefix.size(), prefix) == 0;
}

// Split a CSV row, honouring double quotes and "" escapes. Each field is trimmed.
std::vector<std::string> split_csv(const std::string &s) {
    std::vector<std::string> out;
    std::string cur;
    bool in_quotes = false;
    for (std::size_t i = 0; i < s.size(); ++i) {
        const char ch = s[i];
        if (in_quotes) {
            if (ch == '"') {
                if (i + 1 < s.size() && s[i + 1] == '"') {
                    cur.push_back('"');
                    ++i;
                } else {
                    in_quotes = false;
                }
            } else {
                cur.push_back(ch);
            }
        } else {
            if (ch == '"') {
                in_quotes = true;
            } else if (ch == ',') {
                out.push_back(cur);
                cur.clear();
            } else {
                cur.push_back(ch);
            }
        }
    }
    out.push_back(cur);
    for (std::string &f : out) {
        trim(f);
    }
    return out;
}

#ifdef _WIN32
std::wstring utf8_to_wide(const std::string &s) {
    if (s.empty()) {
        return std::wstring();
    }
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
    if (n <= 0) {
        return std::wstring();
    }
    std::wstring w(static_cast<std::size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], n);
    if (!w.empty() && w.back() == L'\0') {
        w.pop_back();
    }
    return w;
}

long long filetime_to_epoch(const FILETIME &ft) {
    ULARGE_INTEGER ull;
    ull.LowPart = ft.dwLowDateTime;
    ull.HighPart = ft.dwHighDateTime;
    return static_cast<long long>(ull.QuadPart / 10000000ULL - 11644473600ULL);
}
#endif

bool replace_file(const std::string &tmp, const std::string &dst) {
#ifdef _WIN32
    return MoveFileExA(tmp.c_str(), dst.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
#else
    return std::rename(tmp.c_str(), dst.c_str()) == 0;
#endif
}

} // namespace

bool ecm_parse_stage2_line(const std::string &line, EcmStage2Task &task, std::string &err) {
    std::string s = line;
    strip_bom(s);
    trim(s);
    task = EcmStage2Task{};
    task.raw_line = s;

    const std::string prefix = "ECMSTAGE2=";
    if (s.size() <= prefix.size() ||
        s.compare(0, prefix.size(), prefix) != 0) {
        err = "line does not start with ECMSTAGE2=";
        return false;
    }

    const std::vector<std::string> cols = split_csv(s.substr(prefix.size()));
    std::size_t idx = 0;
    if (!is_int_like(cols[0])) {
        task.aid = cols[0];      // optional AID ("N/A" or empty also lands here)
        idx = 1;
    }

    const std::size_t need = idx + 8;
    if (cols.size() < need) {
        err = "not enough fields (need at least " + std::to_string(8) + " core columns)";
        return false;
    }

    task.k = cols[idx];
    task.b = cols[idx + 1];
    task.c = cols[idx + 3];
    task.save_name = cols[idx + 4];
    // cols[idx+5] = B2 (ignored), cols[idx+6] = skip_curves (ignored).

    // n (exponent) must fit in unsigned long.
    {
        const std::string &nstr = cols[idx + 2];
        if (!is_int_like(nstr) || nstr.empty() || nstr[0] == '-') {
            err = "invalid exponent n: '" + nstr + "'";
            return false;
        }
        char *end = nullptr;
        const unsigned long v = std::strtoul(nstr.c_str(), &end, 10);
        if (end == nstr.c_str() || *end != '\0') {
            err = "invalid exponent n: '" + nstr + "'";
            return false;
        }
        task.n = v;
    }

    // curves_to_run.
    {
        const std::string &cstr = cols[idx + 7];
        char *end = nullptr;
        const unsigned long v = std::strtoul(cstr.c_str(), &end, 10);
        if (end == cstr.c_str() || *end != '\0' || v == 0 || v > 0xFFFFFFFFul) {
            err = "invalid curves_to_run: '" + cstr + "'";
            return false;
        }
        task.curves_to_run = static_cast<uint32_t>(v);
    }

    // Optional known factors: a single quoted field "f1,f2,...".
    if (cols.size() > need) {
        const std::vector<std::string> facs = split_csv(cols[need]);
        for (const std::string &f : facs) {
            if (!f.empty()) {
                task.factors.push_back(f);
            }
        }
    }
    return true;
}

bool ecm_parse_ecm2_line(const std::string &line, Ecm2Task &task, std::string &err) {
    std::string s = line;
    strip_bom(s);
    trim(s);
    task = Ecm2Task{};
    task.raw_line = s;

    // Prime95 将 ECM= 与 ECM2= 视为等价 (commonc.c:2934)。
    // 格式: [<AID>,|N/A,|<nul>][FFT2=<fftl>,|<nul>]<k>,<b>,<n>,<c>,<B1>[,<B2>][,<curves>][,<sigma>][,"factors"]
    std::string body;
    if (s.size() > 5 && s.compare(0, 5, "ECM2=") == 0) {
        body = s.substr(5);
    } else if (s.size() > 4 && s.compare(0, 4, "ECM=") == 0) {
        body = s.substr(4);
    } else {
        err = "line does not start with ECM= or ECM2=";
        return false;
    }

    // 分离 quoted known-factors 尾字段 (ECM= 里唯一带引号的字段)。
    std::string unquoted = body;
    std::string factors_raw;
    {
        const std::size_t q0 = body.find('"');
        if (q0 != std::string::npos) {
            unquoted = body.substr(0, q0);
            const std::size_t q1 = body.rfind('"');
            if (q1 != std::string::npos && q1 > q0) {
                factors_raw = body.substr(q0 + 1, q1 - q0 - 1);
            }
        }
    }

    const std::vector<std::string> cols = split_csv(unquoted);
    if (cols.empty() || (cols.size() == 1 && cols[0].empty())) {
        err = "no fields after ECM=/ECM2=";
        return false;
    }

    std::size_t idx = 0;

    // Optional AID: first field is an AID iff it is not integer-like and not "FFT2=...".
    if (!is_int_like(cols[idx]) && !starts_with(cols[idx], "FFT2=")) {
        task.aid = cols[idx];
        ++idx;
    }
    // Optional FFT2 length (informational; e.g. "FFT2=192K").
    if (idx < cols.size() && starts_with(cols[idx], "FFT2=")) {
        task.fft2 = cols[idx].substr(5);
        ++idx;
    }

    // Required: k, b, n, c, B1.
    if (cols.size() < idx + 5) {
        err = "not enough fields (need k,b,n,c,B1)";
        return false;
    }
    task.k = cols[idx];
    task.b = cols[idx + 1];
    task.c = cols[idx + 3];

    {   // n (exponent)
        const std::string &nstr = cols[idx + 2];
        if (!is_int_like(nstr) || nstr.empty() || nstr[0] == '-') {
            err = "invalid exponent n: '" + nstr + "'";
            return false;
        }
        char *end = nullptr;
        const unsigned long v = std::strtoul(nstr.c_str(), &end, 10);
        if (end == nstr.c_str() || *end != '\0') {
            err = "invalid exponent n: '" + nstr + "'";
            return false;
        }
        task.n = v;
    }
    {   // B1 (required)
        const std::string &b1str = cols[idx + 4];
        char *end = nullptr;
        const double v = std::strtod(b1str.c_str(), &end);
        if (end == b1str.c_str() || *end != '\0' || !(v > 0.0)) {
            err = "invalid B1: '" + b1str + "'";
            return false;
        }
        task.B1 = v;
    }

    // Optional positional fields (匹配 Prime95): B2 (默认 0), curves_to_run (默认 100), sigma, factors。
    std::size_t p = idx + 5;
    task.B2 = 0.0;
    if (cols.size() > p) {
        const std::string &b2str = cols[p];
        if (!b2str.empty()) {
            char *end = nullptr;
            const double v = std::strtod(b2str.c_str(), &end);
            if (end != b2str.c_str() && *end == '\0' && v >= 0.0) {
                task.B2 = v;
            }
        }
        ++p;
    }
    task.curves_to_run = 100;   // Prime95 默认 100 条曲线
    if (cols.size() > p) {
        const std::string &cstr = cols[p];
        if (!cstr.empty() && is_int_like(cstr)) {
            char *end = nullptr;
            const unsigned long v = std::strtoul(cstr.c_str(), &end, 10);
            if (end != cstr.c_str() && *end == '\0' && v > 0 && v <= 0xFFFFFFFFul) {
                task.curves_to_run = static_cast<uint32_t>(v);
            }
        }
        ++p;
    }
    if (cols.size() > p) {
        const std::string &sstr = cols[p];
        if (!sstr.empty() && is_int_like(sstr)) {
            char *end = nullptr;
            const unsigned long long v = std::strtoull(sstr.c_str(), &end, 10);
            if (end != sstr.c_str() && *end == '\0' && v > 0) {
                task.has_sigma = true;
                task.sigma = v;
            }
        }
        ++p;
    }
    // known factors (来自 quoted 尾字段)
    if (!factors_raw.empty()) {
        const std::vector<std::string> facs = split_csv(factors_raw);
        for (const std::string &f : facs) {
            if (!f.empty()) {
                task.factors.push_back(f);
            }
        }
    }
    return true;
}

bool ecm_extract_b1_from_save_name(const std::string &save_name, double *b1_out, std::string &err) {
    const std::string suffix = ".save";
    if (save_name.size() <= suffix.size() ||
        save_name.compare(save_name.size() - suffix.size(), suffix.size(), suffix) != 0) {
        err = "save_name does not end with .save: '" + save_name + "'";
        return false;
    }
    const std::string stem = save_name.substr(0, save_name.size() - suffix.size());
    const std::size_t us = stem.rfind('_');
    if (us == std::string::npos || us + 1 >= stem.size()) {
        err = "save_name has no '_<B1>' token: '" + save_name + "'";
        return false;
    }
    const std::string token = stem.substr(us + 1);
    char *end = nullptr;
    const double b1 = std::strtod(token.c_str(), &end);
    if (end == token.c_str() || *end != '\0' || b1 <= 0.0) {
        err = "cannot parse B1 from save_name token '" + token + "'";
        return false;
    }
    *b1_out = b1;
    return true;
}

// Shared N computation: N = (k*b^n + c) / (f1*f2*...), exact integer arithmetic.
static bool compute_n_from_fields(const std::string &k_str, const std::string &b_str,
                                  unsigned long n, const std::string &c_str,
                                  const std::vector<std::string> &factors,
                                  mpz_t N, std::string &err) {
    mpz_t k, b, c;
    mpz_init(k);
    mpz_init(b);
    mpz_init(c);

    bool ok = true;
    if (mpz_set_str(k, k_str.c_str(), 10) != 0) {
        err = "invalid k: '" + k_str + "'";
        ok = false;
    } else if (mpz_set_str(b, b_str.c_str(), 10) != 0) {
        err = "invalid b: '" + b_str + "'";
        ok = false;
    } else if (mpz_set_str(c, c_str.c_str(), 10) != 0) {
        err = "invalid c: '" + c_str + "'";
        ok = false;
    }

    mpz_t bn;
    mpz_init(bn);
    if (ok) {
        mpz_pow_ui(bn, b, n);       // b^n
        mpz_mul(N, k, bn);          // k*b^n
        mpz_add(N, N, c);           // k*b^n + c
        if (mpz_sgn(N) <= 0) {
            err = "computed N is not positive";
            ok = false;
        }
    }

    if (ok) {
        mpz_t f;
        mpz_init(f);
        for (const std::string &fs : factors) {
            if (mpz_set_str(f, fs.c_str(), 10) != 0) {
                err = "invalid known factor: '" + fs + "'";
                ok = false;
                break;
            }
            if (mpz_sgn(f) <= 0) {
                err = "non-positive known factor: '" + fs + "'";
                ok = false;
                break;
            }
            if (!mpz_divisible_p(N, f)) {
                err = "known factor " + fs + " does not divide (k*b^n+c) exactly";
                ok = false;
                break;
            }
            mpz_divexact(N, N, f);
        }
        mpz_clear(f);
    }

    mpz_clear(bn);
    mpz_clear(k);
    mpz_clear(b);
    mpz_clear(c);
    return ok;
}

bool ecm_compute_stage2_n(const EcmStage2Task &task, mpz_t N, std::string &err) {
    return compute_n_from_fields(task.k, task.b, task.n, task.c, task.factors, N, err);
}

bool ecm_compute_ecm2_n(const Ecm2Task &task, mpz_t N, std::string &err) {
    return compute_n_from_fields(task.k, task.b, task.n, task.c, task.factors, N, err);
}

int ecm_worktodo_parse_worker_header(const std::string &line, bool *is_bracket_line) {
    if (is_bracket_line) *is_bracket_line = false;
    if (line.size() < 3 || line.front() != '[' || line.back() != ']') {
        return 0;
    }
    if (is_bracket_line) *is_bracket_line = true;
    const std::string body = line.substr(1, line.size() - 2);
    std::size_t p = 0;
    const char *kw = "worker";
    while (p < body.size() && std::isspace(static_cast<unsigned char>(body[p]))) p++;
    for (const char *k = kw; *k; ++k, ++p) {
        if (p >= body.size() ||
            std::tolower(static_cast<unsigned char>(body[p])) != *k) {
            return 0;
        }
    }
    while (p < body.size() && std::isspace(static_cast<unsigned char>(body[p]))) p++;
    if (p >= body.size() || body[p] != '#') return 0;
    p++;
    while (p < body.size() && std::isspace(static_cast<unsigned char>(body[p]))) p++;
    if (p >= body.size() || !std::isdigit(static_cast<unsigned char>(body[p]))) return 0;
    int n = 0;
    while (p < body.size() && std::isdigit(static_cast<unsigned char>(body[p]))) {
        n = n * 10 + (body[p] - '0');
        if (n > 1000000) return 0;          // absurd index -> not our header
        p++;
    }
    while (p < body.size() && std::isspace(static_cast<unsigned char>(body[p]))) p++;
    return (p == body.size()) ? n : 0;
}

namespace {

// Classification of one raw line for the section-aware queue walk. Keeping the
// original (untrimmed) text is what lets the rewrite preserve the file verbatim.
enum class LineKind { Task, Comment, Header, ForeignBracket };

LineKind classify_line(const std::string &raw, int *section_out, int *header_out) {
    std::string t = raw;
    strip_bom(t);
    trim(t);
    bool bracket = false;
    const int w = ecm_worktodo_parse_worker_header(t, &bracket);
    if (w > 0) {
        if (header_out) *header_out = w;
        if (section_out) *section_out = w;
        return LineKind::Header;
    }
    if (bracket) {
        return LineKind::ForeignBracket;
    }
    if (t.empty() || t[0] == '#') {
        return LineKind::Comment;
    }
    return LineKind::Task;
}

bool worker_matches(int section, int worker) {
    return worker <= 0 || section == worker;
}

} // namespace

bool ecm_worktodo_first_line(const std::string &path, std::string &line) {
    return ecm_worktodo_first_line(path, 1, line);
}

bool ecm_worktodo_first_line(const std::string &path, int worker, std::string &line) {
    std::ifstream in(path);
    if (!in.is_open()) {
        return false;
    }
    int section = 1;                        // lines before any header = worker 1
    std::string l;
    while (std::getline(in, l)) {
        const LineKind kind = classify_line(l, &section, nullptr);
        if (kind != LineKind::Task) {
            continue;
        }
        if (!worker_matches(section, worker)) {
            continue;
        }
        std::string t = l;
        strip_bom(t);
        trim(t);
        line = t;
        return true;
    }
    return false;
}

bool ecm_worktodo_advance(const std::string &path, const std::string &first_line,
                          WorktodoAction action) {
    return ecm_worktodo_advance(path, 1, first_line, action);
}

bool ecm_worktodo_advance(const std::string &path, int worker, const std::string &first_line,
                          WorktodoAction action) {
    std::ifstream in(path);
    if (!in.is_open()) {
        return false;
    }
    std::vector<std::string> lines;
    std::string l;
    while (std::getline(in, l)) {
        lines.push_back(l);
    }
    in.close();

    int section = 1;
    bool found = false;
    for (std::size_t i = 0; i < lines.size(); ++i) {
        const LineKind kind = classify_line(lines[i], &section, nullptr);
        if (kind != LineKind::Task) {
            continue;                       // headers/comments stay untouched
        }
        if (!worker_matches(section, worker)) {
            continue;                       // another worker's line
        }
        // Never remove a different task if the queue changed during computation.
        std::string current = lines[i], expected = first_line;
        strip_bom(current);
        strip_bom(expected);
        trim(current);
        trim(expected);
        if (current != expected) return false;
        if (action == WorktodoAction::Remove) {
            lines.erase(lines.begin() + static_cast<std::vector<std::string>::difference_type>(i));
        } else {
            std::string t = lines[i];
            strip_bom(t);
            trim(t);
            lines[i] = "# ERROR " + t;
        }
        found = true;
        break;
    }
    if (!found) {
        return false;
    }

    const std::string tmp = path + ".tmp";
    std::ofstream out(tmp, std::ios::out | std::ios::trunc);
    if (!out.is_open()) {
        return false;
    }
    for (const std::string &ln : lines) {
        out << ln << "\n";
    }
    out.close();
    if (out.fail()) {
        return false;
    }
    return replace_file(tmp, path);
}

bool ecm_worktodo_list_workers(const std::string &path, std::vector<uint32_t> &workers,
                               std::string &err) {
    err.clear();
    workers.clear();
    std::ifstream in(path);
    if (!in.is_open()) {
        err = "cannot open " + path;
        return false;
    }
    int section = 1;
    std::vector<uint32_t> seen;
    std::string l;
    while (std::getline(in, l)) {
        const LineKind kind = classify_line(l, &section, nullptr);
        if (kind != LineKind::Task) {
            continue;
        }
        const uint32_t w = static_cast<uint32_t>(section);
        if (std::find(seen.begin(), seen.end(), w) == seen.end()) {
            seen.push_back(w);
        }
    }
    std::sort(seen.begin(), seen.end());
    workers = seen;
    return true;
}

bool ecm_append_text_line(const std::string &path, const std::string &line) {
    std::ofstream out(path, std::ios::out | std::ios::app);
    if (!out.is_open()) {
        return false;
    }
    out << line << "\n";
    return !out.fail();
}

void ecm_sync_save_files(const std::string &dir, const std::string &sync_dir_1,
                         const std::string &sync_dir_2, bool full,
                         long long since_epoch_seconds) {
    if (sync_dir_1.empty() && sync_dir_2.empty()) {
        return;
    }
#ifdef _WIN32
    // Use wide APIs so CJK paths (e.g. GIMPS_同步) survive the UTF-8 ini → Win32
    // conversion correctly.
    const std::wstring wdir = utf8_to_wide(dir);
    const std::wstring wpat = wdir + L"\\*.save";
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(wpat.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) {
        return;
    }
    const std::wstring wsync1 = utf8_to_wide(sync_dir_1);
    const std::wstring wsync2 = utf8_to_wide(sync_dir_2);
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            continue;
        }
        if (!full && filetime_to_epoch(fd.ftLastWriteTime) <= since_epoch_seconds) {
            continue;
        }
        const std::wstring wsrc = wdir + L"\\" + fd.cFileName;
        if (!wsync1.empty()) {
            CopyFileW(wsrc.c_str(), (wsync1 + L"\\" + fd.cFileName).c_str(), FALSE);
        }
        if (!wsync2.empty()) {
            CopyFileW(wsrc.c_str(), (wsync2 + L"\\" + fd.cFileName).c_str(), FALSE);
        }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
#else
    DIR *d = opendir(dir.c_str());
    if (d == nullptr) {
        return;
    }
    const auto copy_narrow = [](const std::string &src, const std::string &dst) {
        std::ifstream in(src, std::ios::binary);
        if (!in.is_open()) {
            return;
        }
        std::ofstream out(dst, std::ios::binary | std::ios::trunc);
        if (out.is_open()) {
            out << in.rdbuf();
        }
    };
    struct dirent *e;
    while ((e = readdir(d)) != nullptr) {
        const std::string name = e->d_name;
        if (name.size() < 5 || name.compare(name.size() - 5, 5, ".save") != 0) {
            continue;
        }
        const std::string fullpath = dir + "/" + name;
        struct stat st;
        if (stat(fullpath.c_str(), &st) != 0) {
            continue;
        }
        if (!full && static_cast<long long>(st.st_mtime) <= since_epoch_seconds) {
            continue;
        }
        if (!sync_dir_1.empty()) {
            copy_narrow(fullpath, sync_dir_1 + "/" + name);
        }
        if (!sync_dir_2.empty()) {
            copy_narrow(fullpath, sync_dir_2 + "/" + name);
        }
    }
    closedir(d);
#endif
}
